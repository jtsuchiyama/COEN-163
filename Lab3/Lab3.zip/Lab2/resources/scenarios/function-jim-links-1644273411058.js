(function(window, undefined) {

  var jimLinks = {
    "c8347d3c-1d80-42f1-9f34-ff94c8d721a0" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Button" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_13" : [
        "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"
      ],
      "Paragraph_14" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    },
    "8ccac1c7-7d19-45ee-ba04-621535233857" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_13" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_16" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ],
      "Button" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ]
    },
    "e7513521-1259-46ba-8e70-48c4a5b00b58" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_13" : [
        "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"
      ],
      "Paragraph_15" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    },
    "f69b215b-fc30-406e-9a43-b2314b7fb10d" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_13" : [
        "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"
      ],
      "Paragraph_14" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    },
    "faadd9c0-9f21-4f43-8790-e8a26b7a46d4" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_13" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_16" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    },
    "b58928d0-b415-4b1c-b2d5-b8a6da5033a4" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Button" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_13" : [
        "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"
      ],
      "Paragraph_14" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    },
    "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab" : {
      "Paragraph_8" : [
        "f69b215b-fc30-406e-9a43-b2314b7fb10d"
      ],
      "Paragraph_9" : [
        "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"
      ],
      "Paragraph_10" : [
        "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"
      ],
      "Paragraph_11" : [
        "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"
      ],
      "Paragraph_12" : [
        "e7513521-1259-46ba-8e70-48c4a5b00b58"
      ],
      "Paragraph_13" : [
        "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"
      ],
      "Paragraph_15" : [
        "8ccac1c7-7d19-45ee-ba04-621535233857"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);