	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Rectangle", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Input", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Input", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Input Text Field", "s-Input"]; 

	widgets.descriptionMap[["s-Paragraph_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Input_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_4", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_6", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Button", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_13", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_7", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_15", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_16", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph_17", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "c8347d3c-1d80-42f1-9f34-ff94c8d721a0"]] = ["Text", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Rectangle", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_13", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_16", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Link", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Paragraph", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Input_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Input_1", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Input Text Field", "s-Input_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Input_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_4", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_4", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_4"]; 

	widgets.descriptionMap[["s-Input_3", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_5", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_4", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Input_4", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Input Text Field", "s-Input_4"]; 

	widgets.descriptionMap[["s-Paragraph_6", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Button", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_7", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_14", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_17", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_17", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_17"]; 

	widgets.descriptionMap[["s-Paragraph_18", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_18", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_18"]; 

	widgets.descriptionMap[["s-Paragraph_19", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_19", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_19"]; 

	widgets.descriptionMap[["s-Paragraph_20", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_20", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_20"]; 

	widgets.descriptionMap[["s-Paragraph_21", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_21", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_21"]; 

	widgets.descriptionMap[["s-Paragraph_22", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_22", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_22"]; 

	widgets.descriptionMap[["s-Paragraph_23", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_23", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_23"]; 

	widgets.descriptionMap[["s-Paragraph_24", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_24", "8ccac1c7-7d19-45ee-ba04-621535233857"]] = ["Text", "s-Paragraph_24"]; 

	widgets.descriptionMap[["s-Rectangle", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_2", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Paragraph", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_14", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-d5a257be", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-d5a257be", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-019a5287", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-019a5287", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_7", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_7", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-36fbe111", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-36fbe111", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_8", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_8", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-a4321efa", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-a4321efa", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_9", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_9", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-c6eca7ea", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-c6eca7ea", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_10", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_10", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-091e09dc", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-091e09dc", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_11", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_11", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_13", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_15", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "e7513521-1259-46ba-8e70-48c4a5b00b58"]] = ["Link", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Rectangle", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_2", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Paragraph", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_3", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_13", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "f69b215b-fc30-406e-9a43-b2314b7fb10d"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Rectangle", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Paragraph_13", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-a936a194", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-a936a194", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-5b73233c", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-5b73233c", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_7", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_7", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-30300d6f", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-30300d6f", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_8", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_8", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-03680b31", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-03680b31", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_9", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_9", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-40859874", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-40859874", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_10", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_10", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-fd2d5fef", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-fd2d5fef", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Text_cell_11", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Text_cell_11", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text Table", "s-Table"]; 

	widgets.descriptionMap[["s-Paragraph_14", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Text", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_15", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Paragraph_16", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_16", "faadd9c0-9f21-4f43-8790-e8a26b7a46d4"]] = ["Link", "s-Paragraph_16"]; 

	widgets.descriptionMap[["s-Rectangle", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Rectangle_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Rectangle", "s-Rectangle_3"]; 

	widgets.descriptionMap[["s-Paragraph", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Input_2", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Input_2", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Input Text Field", "s-Input_2"]; 

	widgets.descriptionMap[["s-Paragraph_5", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_5", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph_5"]; 

	widgets.descriptionMap[["s-Input_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Input_3", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Input Text Field", "s-Input_3"]; 

	widgets.descriptionMap[["s-Paragraph_6", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_6", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph_6"]; 

	widgets.descriptionMap[["s-Button", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Button", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Button", "s-Button"]; 

	widgets.descriptionMap[["s-Paragraph_13", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_14", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_7", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_7", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph_7"]; 

	widgets.descriptionMap[["s-Paragraph_15", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "b58928d0-b415-4b1c-b2d5-b8a6da5033a4"]] = ["Text", "s-Paragraph_15"]; 

	widgets.descriptionMap[["s-Rectangle", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Rectangle", "s-Rectangle"]; 

	widgets.descriptionMap[["s-Rectangle_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Rectangle", "s-Rectangle_1"]; 

	widgets.descriptionMap[["s-Image", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Rectangle_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Rectangle_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Rectangle", "s-Rectangle_2"]; 

	widgets.descriptionMap[["s-Paragraph_8", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_8", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_8"]; 

	widgets.descriptionMap[["s-Paragraph_9", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_9", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_9"]; 

	widgets.descriptionMap[["s-Paragraph_10", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_10", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_10"]; 

	widgets.descriptionMap[["s-Paragraph_11", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_11", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_11"]; 

	widgets.descriptionMap[["s-Paragraph_12", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_12", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_12"]; 

	widgets.descriptionMap[["s-Paragraph_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_1", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Paragraph", "s-Paragraph_1"]; 

	widgets.descriptionMap[["s-Paragraph_3", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_3", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Text", "s-Paragraph_3"]; 

	widgets.descriptionMap[["s-Image_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Paragraph", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Text", "s-Paragraph"]; 

	widgets.descriptionMap[["s-Paragraph_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_2", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Paragraph", "s-Paragraph_2"]; 

	widgets.descriptionMap[["s-Paragraph_14", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_14", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_14"]; 

	widgets.descriptionMap[["s-Paragraph_13", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_13", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_13"]; 

	widgets.descriptionMap[["s-Paragraph_15", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ""; 

			widgets.rootWidgetMap[["s-Paragraph_15", "6a35cd27-3fa7-4dcf-b248-ebd1c270c6ab"]] = ["Link", "s-Paragraph_15"]; 

	