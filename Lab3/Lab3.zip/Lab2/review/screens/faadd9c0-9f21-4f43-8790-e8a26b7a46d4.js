var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1644273411058.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1644273411058-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-faadd9c0-9f21-4f43-8790-e8a26b7a46d4" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Sheet Music" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/faadd9c0-9f21-4f43-8790-e8a26b7a46d4-1644273411058.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/faadd9c0-9f21-4f43-8790-e8a26b7a46d4-1644273411058-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/faadd9c0-9f21-4f43-8790-e8a26b7a46d4-1644273411058-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="1280.0px" datasizeheight="90.0px" datasizewidthpx="1279.9999999999995" datasizeheightpx="90.0" dataX="0.0" dataY="720.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="1280.0px" datasizeheight="27.0px" datasizewidthpx="1279.9999999999995" datasizeheightpx="27.0" dataX="0.0" dataY="81.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="1280.0px" datasizeheight="81.4px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/8bf2690e-4632-402a-a7ec-a49d5e49c402.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="1280.0px" datasizeheight="190.4px" dataX="-0.0" dataY="108.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/72de403f-039c-4722-97b4-570b6d5670f7.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="333.0px" datasizeheight="44.4px" datasizewidthpx="333.0214843750003" datasizeheightpx="44.410883665468134" dataX="473.5" dataY="15.4" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Home"   datasizewidth="60.0px" datasizeheight="54.0px" dataX="192.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Home</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_9" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Login"   datasizewidth="60.0px" datasizeheight="54.0px" dataX="736.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">Login</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_10" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Create an Account"   datasizewidth="172.0px" datasizeheight="104.0px" dataX="507.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">Create an Account</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Staff"   datasizewidth="53.0px" datasizeheight="104.0px" dataX="297.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">Staff<br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Scheduling"   datasizewidth="114.0px" datasizeheight="104.0px" dataX="864.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">Scheduling<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Contact Us:ukuleleaina@gm"   datasizewidth="400.0px" datasizeheight="133.0px" dataX="9.0" dataY="722.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Contact Us:<br />ukuleleaina@gmail.com</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Ukulele ʻĀina"   datasizewidth="257.3px" datasizeheight="42.0px" dataX="505.0" dataY="24.1" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Ukulele ʻĀina</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_13" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Sheet Music"   datasizewidth="114.0px" datasizeheight="104.0px" dataX="1021.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_13_0">Sheet Music<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Table" class="pie table firer commentable non-processed" customid="Table"  datasizewidth="638.0px" datasizeheight="266.0px" dataX="283.0" dataY="363.0" originalwidth="637.0000000000002px" originalheight="264.9999999999997px" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <table summary="">\
              <tbody>\
                <tr>\
                  <td id="s-Text_cell" class="pie textcell manualfit firer ie-background non-processed" customid="Song Name"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_0">Song Name</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_7" class="pie textcell manualfit firer ie-background non-processed" customid="Download Link"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_7_0">Download Link</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_8" class="pie textcell manualfit firer ie-background non-processed" customid="Yoru Ni Kakeru"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_8_0">Yoru Ni Kakeru</span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_9" class="pie textcell manualfit firer ie-background non-processed" customid="https://drive.google.com/"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_9_0">https://drive.google.com/file/d/14JysIyW6xyF6Bi_TSvm3k8cOudp-zK72/view?usp=sharing</span></div></div></div></div></div></div>  </td>\
                </tr>\
                <tr>\
                  <td id="s-Text_cell_10" class="pie textcell manualfit firer ie-background non-processed" customid="Text_cell"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_10_0"></span></div></div></div></div></div></div>  </td>\
                  <td id="s-Text_cell_11" class="pie textcell manualfit firer ie-background non-processed" customid="Text_cell"     datasizewidth="319.5px" datasizeheight="89.3px" dataX="0.0" dataY="0.0" originalwidth="318.5000000000001px" originalheight="88.33333333333324px" ><div class="cellContainerChild"><div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div><div class="borderLayer"><div class="paddingLayer"><div class="clipping"><div class="content"><div class="valign"><span id="rtr-s-Text_cell_11_0"></span></div></div></div></div></div></div>  </td>\
                </tr>\
              </tbody>\
            </table>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_14" class="pie richtext autofit firer ie-background commentable non-processed" customid="Sheet Music Library"   datasizewidth="277.3px" datasizeheight="39.0px" dataX="463.3" dataY="312.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_14_0">Sheet Music Library</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_15" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Google Drive Folder"   datasizewidth="192.0px" datasizeheight="54.0px" dataX="506.0" dataY="635.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_15_0">Google Drive Folder</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_16" class="pie richtext manualfit firer mouseenter mouseleave click ie-background commentable non-processed" customid="Support"   datasizewidth="68.0px" datasizeheight="104.0px" dataX="1176.0" dataY="86.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_16_0">Support<br /><br /><br /></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;